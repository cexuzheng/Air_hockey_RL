import socket
import json
Data=[1,2,3,4]

# Create a TCP/IP socket
socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Connect the socket to the port where the server is listening
server_address = ('10.5.3.122', 9988)
print('connecting to %s port %s' % server_address)
socket.connect(server_address)

try:
	# Send data
	#'This is the message. It will be repeated.'
	#message = json.dumps(Data)
	#print ('sending "%s"' %message)
	#socket.sendall(message.encode())
	
	amount_received=0
	while True:
		data = socket.recv(1024)
		amount_received += len(data)
		print( 'received "%s"' %data.decode())
finally:
	print( 'closing socket')
	socket.close()
