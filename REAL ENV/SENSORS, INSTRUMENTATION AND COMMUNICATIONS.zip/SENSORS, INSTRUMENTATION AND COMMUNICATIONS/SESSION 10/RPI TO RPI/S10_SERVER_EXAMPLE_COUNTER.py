import socket

from threading import *
import time
#Sinppet 3 of code
def clientthread(conn):
	#Sending message to connected client
	conn.send('''Welcome to the server. Type something and hit enter\n'''.encode())
	#send only takes string

	#infinite loop so that function
	#do not terminate and thread do not end.
	counter=0
	while True:
		time.sleep(1)	
		counter=counter+1
		print(f"The counter value is {counter}")
		conn.sendall(f"The counter value is {counter}".encode())
	#came out of loop
	conn.close()



#create an INET, STREAMing socket

serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

#bind the socket to a public host,
# and a well-known port

#This one get access from outside
#serversocket.bind((socket.gethostname(), 8080))
#This one get access just from the machine
serversocket.bind(('localhost', 9988))
#become a server socket

serversocket.listen(5)

#New code
while 1:
	#wait to accept a connection - blocking call
	conn, addr = serversocket.accept()
	print('Connected with ' + addr[0] + ':' + str(addr[1]))
	#start new thread takes 1st argument as a function name to be run,
	#second is the tuple of arguments to the function.
	#start_new_thread(clientthread ,(conn,))
	Thread(target=clientthread ,args=(conn,)).start()
serversocket.close()

