#!/usr/bin/env python3

"""
Created on Tue May 10 12:13:53 2022

@author: manelvelasco
"""

import serial
import time

# In order to get the port you can
# use the arduino enviroment or you can
# use the commandline comand ’dmesg’
ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
data=ser.readline()

pevious_time=time.time()
while(time.time()-pevious_time<10.0):
	data=ser.readline()
	print(data.decode().strip())

#Never forget this line
ser.close()
