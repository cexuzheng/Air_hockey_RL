load('data.csv');
total_time=data(1,1);
reads=data(2:end);
num_samples=length(reads);
%%
T=total_time/num_samples;   %Sampling period
Fs=1/T;                     %Sampling frequency
L=num_samples;              %Length of signal
t=(0:L-1)*T;                %Time vector



Y=fft(reads-mean(reads));
P2 = abs(Y);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;

figure
plot(f,P1);

figure
plot(reads);

significative_bits=log2(3.3)-log2(std(reads))