import RPi.GPIO as GPIO
import time

#Constants
max_voltage=3.3
t_step=0.0

#Set pin numbers
CS_pin=24
Raspin_pin=22		#Dout
Raspout_pin=17		#Din
CLK_pin=23		

#Init pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(CS_pin, GPIO.OUT)
GPIO.setup(Raspout_pin, GPIO.OUT)
GPIO.setup(CLK_pin, GPIO.OUT)		
GPIO.setup(Raspin_pin,GPIO.IN,pull_up_down=GPIO.PUD_OFF)
GPIO.output(CS_pin,True)
GPIO.output(Raspout_pin,False)
GPIO.output(CLK_pin,False)


def clock_high():
	GPIO.output(CLK_pin,True)
	time.sleep(t_step)

def clock_down():
	GPIO.output(CLK_pin,False)
	time.sleep(t_step)

def init_read():
	GPIO.output(CS_pin,True)
	clock_down()
	clock_high()
	GPIO.output(CS_pin,False)

def send_data_to_adc():
	#Start
	GPIO.output(Raspout_pin,True) ##################
	clock_down()
	clock_high()
	
	#Single mode
	GPIO.output(Raspout_pin,True)
	clock_down()
	clock_high()
	
	#CH0 is when D2=* and D1=0 and D0=0
	#D2=0
	GPIO.output(Raspout_pin,False)
	clock_down()
	clock_high()
	
	#D1=0
	GPIO.output(Raspout_pin,False)
	clock_down()
	clock_high()
	
	#D0=0
	GPIO.output(Raspout_pin,False)
	clock_down()
	clock_high()
	
	#Wait 2 steps between send and receive data
	clock_down()
	clock_high()
	
def read_adc_value():
	#Null bit
	clock_down()
	clock_high()
	
	#Read all the values
	value=0
	max_value=2**12
	for i in range(11, -1, -1):
		clock_down()
		value+=(2**i)*GPIO.input(Raspin_pin)
		clock_high()
		
	voltage=(max_voltage*value)/max_value
	return voltage
	
	
#################################################
##################### MAIN ######################
#################################################
reads_per_seconds=0
init_time=time.time()

while True:
	init_read()
	send_data_to_adc()
	fdsafds=read_adc_value()
	print(fdsafds)
	reads_per_seconds+=1;
	
	if(time.time()-init_time>1):
		print(reads_per_seconds)
		reads_per_seconds=0
		init_time=time.time()
				
GPIO.cleanup()

	
	
	
	
