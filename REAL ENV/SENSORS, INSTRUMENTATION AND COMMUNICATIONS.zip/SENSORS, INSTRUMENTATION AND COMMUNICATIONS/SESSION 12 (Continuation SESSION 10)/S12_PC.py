#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 19 18:48:48 2020

@author: mvelasco
"""

#import paho.mqtt.publish as publish
#publish.single("paho/test/simple", "payload", hostname="127.0.0.1")
import socket
import json
import paho.mqtt.client as mqtt #import the client1
import time

broker_address="test.mosquitto.org" 

# Create a TCP/IP socket
socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Connect the socket to the port where the server is listening
server_address = ('10.5.3.122', 9987)
print('connecting to %s port %s' % server_address)
socket.connect(server_address)


#broker_address="iot.eclipse.org" #use external broker
client = mqtt.Client("State_publisher") #create new instance
client.connect(broker_address) #connect to broker


	


try:
	# Send data
	#'This is the message. It will be repeated.'
	#message = json.dumps(Data)
	#print ('sending "%s"' %message)
	#socket.sendall(message.encode())
	
	amount_received=0
	while True:
		data = socket.recv(1024)
		amount_received += len(data)
		print( 'received "%s"' %data.decode())
		client.publish("MUAR_SIC/CONTROL/ALEX_AHMAD_DANI/STATES",data.decode())#publish
		
		
		
finally:
	print( 'closing socket')
	socket.close()
