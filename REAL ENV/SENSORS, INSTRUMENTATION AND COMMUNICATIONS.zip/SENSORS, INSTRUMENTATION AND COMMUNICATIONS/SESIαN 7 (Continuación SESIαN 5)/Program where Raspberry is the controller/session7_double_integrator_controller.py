import smbus
import time
import math
# for RPI version 1, use "bus = smbus.SMBus(0)"
bus = smbus.SMBus(1)

# This is the address we setup in the Arduino Program
address = 0x0F

#Initialize previous values
v1 = 0
v2 = 0
ref = -1
u = 0
cont = 0
x1=0
x2=0
Nx = [1,0]
Nu = 0
K = [ 0.4763 ,  -1.3860]

def readNumber():
	number_ls = bus.read_byte(address)
	number_ms = bus.read_byte(address)
	number_ms = number_ms << 8 
	return (number_ls+number_ms)
	
def writeNumber(value):
	bus.write_byte(address, value)
	return -1
	
while True:
	cont = cont + 1
	if (cont == 200):
		ref = 1
	elif (cont == 400):
		ref = -1
		cont = 0



	v1 = readNumber()
	v2 = readNumber()
	print(v1)
	print(v2)
	time.sleep(0.025)
	
	x1 = (v1*5.0/1023.0)-2.5; 
	x2 = (v2*5.0/1023.0)-2.5;
	
	u = K[0]*(ref*Nx[0]-x1) + K[1]*(ref*Nx[1]-x2) + Nu*ref
	u_shifted=u+2.5
	u_PWM = u_shifted*255.0/5.0
	
	writeNumber(int(u_PWM))
	# sleep 5 ms
	time.sleep(0.025)
