import smbus
import time
# for RPI version 1, use "bus = smbus.SMBus(0)"
bus = smbus.SMBus(1)

# This is the address we setup in the Arduino Program
address = 0x0F

def readNumber():
	number = bus.read_byte(address)
	number2 = bus.read_byte(address)
	return number
		
while True:
	number = readNumber()
	print ("Arduino: Hey RPI, I received a digit ", number)
	print ()
	
	# sleep one second
	time.sleep(1)
