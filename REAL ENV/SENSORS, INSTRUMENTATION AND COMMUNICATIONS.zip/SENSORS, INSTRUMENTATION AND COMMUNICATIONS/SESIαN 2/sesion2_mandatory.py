import RPi.GPIO as GPIO
import time
import math

out_pin=11
in_pin=12

charging_times =[]
def DischargeCap():
	GPIO.output(out_pin, 0)
	GPIO.setup(in_pin, GPIO.OUT)	
	GPIO.output(in_pin, 0)			
	time.sleep(1)
	GPIO.setup(in_pin,GPIO.IN, pull_up_down=GPIO.PUD_OFF)	#define input pin (default 0)	


def ReadCap():
	init_time=time.time()
	GPIO.output(out_pin, 1)
#	print("Aqui estoy")
	while(GPIO.input(in_pin)==0):
		pass
	charge_time= time.time() - init_time
	return charge_time
	
	
	
	
	
##############################################
#################### MAIN ####################
##############################################
GPIO.setmode(GPIO.BOARD)
GPIO.setup(out_pin, GPIO.OUT)					#define output pin
GPIO.setup(in_pin,GPIO.IN,pull_up_down=GPIO.PUD_OFF)		#define input pin (default 0)	

number_of_tests=20
mean_charge_time=0.0
for i in range(number_of_tests):
	DischargeCap()
	local_measured_time=ReadCap()
	mean_charge_time+=local_measured_time
	charging_times.append(local_measured_time)
mean_charge_time=mean_charge_time/number_of_tests

#Obtain resistor value
vc=2.31
vin=3.3
c=1e-6
t=mean_charge_time
R=-t/(c*math.log(1-(vc/vin)))

#Obtain real vih min
R_real = 1000
vih_min = vin*(1-math.exp(-t/(R_real*c)))


#Obtain new resistor value with real vih
R_real_test=-t/(c*math.log(1-(vih_min/vin)))


#Obtain standard deviation
def variance(data):
	# Number of observations
	n = len(data)
	# Mean of the data
	mean = sum(data) / n
	# Square deviations
	deviations = [(x - mean) ** 2 for x in data]
	# Variance
	variance = sum(deviations) / n
	return variance


res_variance = variance(charging_times)
print("Measured time: ", mean_charge_time)
print("Measured R: ", R)
print("Measured vih: ", vih_min)
print("Measured R real test: ", R_real_test)
print("Variance: ", res_variance)
print("Deviation: ", math.sqrt(res_variance))
DischargeCap()
GPIO.cleanup()

