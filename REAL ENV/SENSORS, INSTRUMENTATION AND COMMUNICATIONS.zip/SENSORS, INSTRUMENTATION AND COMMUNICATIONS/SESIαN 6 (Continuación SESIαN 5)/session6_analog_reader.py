import smbus
import time
# for RPI version 1, use "bus = smbus.SMBus(0)"
bus = smbus.SMBus(1)

# This is the address we setup in the Arduino Program
address = 0x0F

def readNumber():
	number_ls = bus.read_byte(address)
	number_ms = bus.read_byte(address)
	number_ms = number_ms << 8 
	return (number_ls+number_ms)
	
while True:
	number = readNumber()
	
	print (number)
	
	# sleep one second
	time.sleep(1)
