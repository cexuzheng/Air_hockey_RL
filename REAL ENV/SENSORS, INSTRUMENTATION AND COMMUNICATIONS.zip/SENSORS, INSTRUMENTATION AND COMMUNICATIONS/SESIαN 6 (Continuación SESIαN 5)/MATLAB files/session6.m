clear
clc
close all

A = [0 -23.8095; 0 0]
B = [0 ;-23.8095]
C = [1 0]
D = [0]


sys = ss(A,B,C,D)
tf_sys = tf(sys)


p = [-500;-600]
K = place(A,B,p)

cl = ss(A-B*K,B,C,D)
figure
step(cl)

ABC_inv = inv([A B; C 0])
Nx_Nu = ABC_inv*[0;0;1] 


Nx = Nx_Nu(1:2,1)
Nu = Nx_Nu(3,1)



