import RPi.GPIO as GPIO
import time

for i in range(300):
	GPIO.setmode(GPIO.BCM)		#Que estas siguiendo la numeracion del chip BCM.
					#Si le pones BOARD estarias en modo de la placa, 
					#y el numero para este mismo pin seria 16
	GPIO.setup(23,GPIO.OUT)
	GPIO.output(23,False)

	time.sleep(0.03)

	GPIO.output(23,True)
	time.sleep(0.03)

print("UPC")
GPIO.cleanup()
