import math
a=False
if a == True:
	print "This line belongs to the code block"
	print "this line also belongs to the code block"
elif a == False:
	print "a is false"
else:
	print "this line also belongs to the code block"

myvar = ["this", "is", "a", "list"]

#for index,pepito in enumerate(myvar):
#	print pepito + str(index)
#	

# 	   #start,stop,step
#for i in range(5,25,3):
#	print i

#for i in range(5):
#	print i*i	
	
##Better because range creates a list in memory:
#i=0
#while i<5:
#	print i*i
#	i+=1
	
def power2(a):
	#return a*a
	return a**2

def change_int(a):
	a=a**2

def change_list(a):
	for i,element in enumerate(a):
		a[i] = power2(element)

b=2
change_int(b)
print b

elem_list=[1,3,5,7]
change_list(elem_list)
print elem_list

# Mutable: Lists
# Non-Mutable: integers
# A list is passed by reference. An integer, floats, chars, etc are passed by value.

print math.sin(0)

